#include <stdio.h>

int main()
{
    int a = 32; 

    printf("a %c b", a);
}