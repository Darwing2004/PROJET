#include <stdio.h>
#include <stdlib.h>

int **allocate_matricee(int N, int M)
{
    int **matrice = (int **)malloc(N * sizeof(int *));

    for (int i = 0; i < N; i++)
    {
        matrice[i] = (int *)malloc(M * sizeof(int));
    }

    if (matrice == NULL)
    {
        printf("Erreur d'allocation\n");
        exit(1);
    }

    for (int i = 0; i < N; i++)
    {
        if (matrice[i] == NULL)
        {
            printf("Erreur d'allocation\n");
            exit(1);
        }
    }
}


int **read_and_fill_matrix(char *number, int N, int M)
{

    FILE *file = fopen(number, "r");
    if (file == NULL)
    {
        printf("Erreur");
        exit(1);
    }

    fscanf(file, "%d %d", &N, &M);
    int **matrice = allocate_matricee(N, M);

    printf("N = %d et M = %d\n", N, M);

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            fscanf(file, "%d", matrice[i][j]);
        }
    }

    printf("BOOM");

    printf("MATRICE : ");
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            printf("%d ", matrice[i][j]);
        }

        printf("\n");
    }

    fclose(file);
}

void print_matrix(int **mat, int N, int M)
{
    printf("MATRICE : ");
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            printf("%d ", mat[i][j]);
        }

        printf("\n");
    }
}

int main()
{
    int N, M;

    char *file = "number.txt";
    int **matrice;
    read_and_fill_matrix(file, N, M);

    print_matrix(matrice, N, M);
}
