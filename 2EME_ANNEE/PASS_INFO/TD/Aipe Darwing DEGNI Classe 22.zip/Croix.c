#include <stdio.h>

#include <stdio.h>

void croix(int nbr_c, int nbr_l)
{
    int i = 0;
    int j = 0;

    for (i = 0; i < nbr_l; i++)
    {
        while (j < nbr_c)
        {
            if ((i + j == nbr_l - 1) )
            {
                printf("* ");
            }
            else
            {
                printf("  ");
            }
            j++;
        }
        printf("\n");
        j = 0;
    }
}

int main()
{
    int nbr_l, nbr_c;
    printf("Choisisez le nombre de ligne:");
    scanf("%d", &nbr_l);

    printf("Choisisez le nombre de colonne:");
    scanf("%d", &nbr_c);

    croix(nbr_c, nbr_l);
}
