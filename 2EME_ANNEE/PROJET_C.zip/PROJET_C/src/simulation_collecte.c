#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "definition_fourmis.h"

// On calcule la nourriture que l'on doit trouver pour que chaque fourmis puissent manger
void objectif_nourriture(Fourmiliere *fourmiliere)
{
    for (int i = 0; i < fourmiliere->nombresOccupants; i++)
    {
        fourmiliere->ressources.objectif += fourmiliere->fourmis[i].consommation_nourriture;
    }

    printf("Stock deja present dans la fourmiliere : %d\n", fourmiliere->ressources.stockNourriture);

    // On calcule la nourriture qu'on doit ramener pour atteindre l'objectif

    printf("L'objectif est de %d unite(s) de nourriture pour %d fourmis !\n", fourmiliere->ressources.objectif, fourmiliere->nombresOccupants);
}

// Les fourmis exploratrices cherchent et trouvent des sources
void explorer_source(Fourmiliere *fourmiliere)
{
    // Facteur chance qui sera modifier en fonction des evements et des température
    fourmiliere->decouvertes = 0; // Réinitialisation des découvertes
    for (int i = 0; i < fourmiliere->nombresOccupants; i++)
    {
        if (strcmp(fourmiliere->fourmis[i].role, "EXPLORATRICE") == 0 && fourmiliere->fourmis[i].role_specifique.exploratrice.decouvertes > 0)
        {
            // Une fourmi exploratrice trouve 1 sources de nourriture
            fourmiliere->fourmis[i].role_specifique.exploratrice.decouvertes = 1;
            // On rajoute la découverte dans le nombre e découverte totale
            fourmiliere->decouvertes += fourmiliere->fourmis[i].role_specifique.exploratrice.decouvertes;

            // On diminue de 20 l'endurance de la fourmis exploratrice:
            fourmiliere->fourmis[i].role_specifique.exploratrice.endurance = fourmiliere->fourmis[i].role_specifique.exploratrice.endurance - 20;
        }
    }
    printf("Les fourmis exploratrices ont decouvert %d sources de nourritures (BRAVO !!!) !\n", fourmiliere->decouvertes);
}

int ChercherNourriture(Fourmiliere *fourmiliere, Ressources *ressources, Source_nourriture **source)
{


    // Les fourmis mangent essentiellement des humains
    strcpy(ressources->categories, "HUMAIN");
    printf("La nourriture trouvée est de %s\n", ressources->categories);
    printf("TEST2\n");
    // Apport nutritif des humains
    ressources->sante_boost = 20;

    // Vérifiez la valeur de 'decouvertes' avant l'allocation
    printf("Nombre de découvertes : %d\n", fourmiliere->decouvertes);
    printf("TEST2\n");
    *source = malloc(sizeof(Source_nourriture) * fourmiliere->decouvertes);

    if (*source == NULL)
    {
        printf("ERREUR : l'allocation n'a pas réussi\n");
        exit(1);
    }
    else
    {
        printf("Mémoire allouée avec succès\n");
    }

    int nourrituretotal = 0;
    for (int i = 0; i < fourmiliere->decouvertes; i++)
    {
        (*source)[i].quantite_nourriture = ressources->sante_boost;
        nourrituretotal += (*source)[i].quantite_nourriture;
        printf("Il y a %d unités de nourriture dans la source %d\n", (*source)[i].quantite_nourriture, i + 1);
    }

    printf("Total nourriture trouvée : %d\n", nourrituretotal);
    return nourrituretotal;
}

// Les fourmis ouvrières partent récupérer la nourriture.
void collect_nourriture(Source_nourriture *source, Fourmiliere *fourmiliere)
{
    int collecteTotale = 0;

    while (source->quantite_nourriture > 0)
    {
        int nourritureCollectee = 0;

        for (int i = 0; i < fourmiliere->nombresOccupants; i++)
        {
            if (strcmp(fourmiliere->fourmis[i].role, "OUVRIERE") == 0 &&
                fourmiliere->fourmis[i].role_specifique.ouvriere.nourritureCollect < fourmiliere->fourmis[i].role_specifique.ouvriere.capacite)
            {
                // Une unité de nourriture collectée
                fourmiliere->fourmis[i].role_specifique.ouvriere.nourritureCollect++;
                source->quantite_nourriture--;
                nourritureCollectee++;

                // Arrêter si la source est vide
                if (source->quantite_nourriture == 0)
                    break;
            }
        }

        collecteTotale += nourritureCollectee;

        // Si aucune fourmi n'a collecté, on quitte la boucle pour éviter un boucle infinie
        if (nourritureCollectee == 0)
        {
            printf("Aucune collecte supplementaire possible. Source restante : %d\n", source->quantite_nourriture);
            break;
        }
    }

    printf("Collecte totale effectuee : %d unitees. Reste dans la source : %d\n\n", collecteTotale, source->quantite_nourriture);
}

void deposer_nourriture(Fourmiliere *fourmiliere)
{
    for (int i = 0; i < fourmiliere->nombresOccupants; i++)
    {
        if (strcmp(fourmiliere->fourmis[i].role, "OUVRIERE") == 0)
        {
            printf("***** Avant depot *****\nStock %d, Nourriture collecte par fourmi %d : %d\n", fourmiliere->ressources.stockNourriture, i, fourmiliere->fourmis[i].role_specifique.ouvriere.nourritureCollect);
            fourmiliere->ressources.stockNourriture += fourmiliere->fourmis[i].role_specifique.ouvriere.nourritureCollect;
            fourmiliere->fourmis[i].role_specifique.ouvriere.nourritureCollect = 0;
            printf("***** Apres depot *****\nStock %d, Nourriture collecte par fourmi %d : %d\n", fourmiliere->ressources.stockNourriture, i, fourmiliere->fourmis[i].role_specifique.ouvriere.nourritureCollect);
            printf("\n");
        }
    }

    printf("La nourriture collectee a ete stockee dans la fourmiliere (%d de nourriture(s)) !\n", fourmiliere->ressources.stockNourriture);
}

void simulation_collect_nourriture(Fourmiliere *fourmiliere, Ressources *ressource)
{
    printf("\n***************************************************************************\n");
    printf("******************** SIMULATION COLLECTE DE NOURRITURE ********************\n");
    printf("***************************************************************************\n\n");

    // ETAPE 1 : On définit l'objectif en comptant la nourriture que chacune des fourmis mange
    printf("********** OBJECTIF NOURRITURE **********\n");
    objectif_nourriture(fourmiliere);
    printf("\n");

    // Etape 2 : On commence par explorer et trouver des sources de nourritures
    printf("********** EXPLORATION **********\n");
    explorer_source(fourmiliere);
    printf("\n");

    // On vérifie si les fourmis exploratrices ont trouvé des sources de nourriture.
    if (fourmiliere->decouvertes == 0)
    {
        printf("Aucune source de nourriture a ete trouve !\n");
        return;
    }

    // Etape 3 : On génère des sources de nourriture
    printf("********** GESTION SOURCE DE NOURRITURE **********\n");
    Source_nourriture *source = NULL; // Déclaration du pointeur
    int totalnourriture = ChercherNourriture(fourmiliere, ressource, &source);
    printf("TEST\n");

    if (totalnourriture < fourmiliere->ressources.objectif)
    {
        printf("Il n'y a pas assez de nourriture pour alimenter toute la fourmiliere (Dommage...) !\n");
    }

    // Etape 4 : On collecte et stocke la nourriture dans la fourmilière jusqu'à atteindre l'objectif demandé
    printf("********** COLLECTE DE LA NOURRITURE **********\n");
    for (int i = 0; i < fourmiliere->decouvertes; i++)
    {
        if (source[i].quantite_nourriture > 0)
        {
            printf("****** SOURCE %d ******\n", i + 1);
            collect_nourriture(&source[i], fourmiliere);
            deposer_nourriture(fourmiliere);
            printf("\n");
        }
    }

    printf("\n");

    if (fourmiliere->ressources.stockNourriture >= fourmiliere->ressources.objectif)
    {
        printf("Objectif atteint : %d unités de nourriture ont été collectées et stockées pour un objectif de %d !\n", fourmiliere->ressources.stockNourriture, fourmiliere->ressources.objectif);
    }
    else
    {
        printf("Objectif non atteint : %d unités de nourriture ont été collectées et stockées pour un objectif de %d !\n", fourmiliere->ressources.stockNourriture, fourmiliere->ressources.objectif);
    }

    free(source); // Libération de la mémoire allouée
    source = NULL;
}
