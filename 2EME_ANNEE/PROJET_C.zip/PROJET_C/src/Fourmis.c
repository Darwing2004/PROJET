#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "definition_fourmis.h"

// Fonction pour ajouter de la nourriture
void ajouterNourriture(Ressources *ressources, int quantite) // Ajout de la nourriture
{
    if (quantite <= 0)
    {
        printf("Mince t'as fais une erreur bete. la quantite a ajouter doit être positive !\n");
        return;
    }

    ressources->stockNourriture += quantite;
    printf("Ajoute %d unites de nourriture. Le stock actuel est %d.\n", quantite, ressources->stockNourriture);
}

// Fonction pour consommer de la nourriture
bool consommerNourriture(Ressources *ressources, int quantite) // Consomation nourriture
{
    if (quantite <= 0)
    {
        printf("Mince t'as fais une erreur bete. La quantite a consommer doit être positive.\n");
        return false;
    }

    if (quantite > ressources->stockNourriture)
    {
        printf("Mince Pas assez de nourriture dans le stock.\n");
        return false;
    }

    ressources->stockNourriture -= quantite;
    ressources->Consommation += quantite;

    printf("Consomme %d unites de nourriture. Stock restant : %d.\n", quantite, ressources->stockNourriture);
    return true;
}

// Fonction pour la simulation de la consommation de nourriture
void simulerConsommation(Ressources *ressources, FourmiChimere *fourmis, int nombreDeFourmis)
{
    for (int i = 0; i < nombreDeFourmis; i++)
    {
        int conso = 0;

        if (strcmp(fourmis->role, "OUVRIERE") == 0)
        {
            conso = 10;
        }
        else if (strcmp(fourmis->role, "GARDE_ROYAL") == 0)
        {
            conso = 8;
        }
        else if (strcmp(fourmis->role, "SOLDAT") == 0)
        {
            conso = 5;
        }
        else if (strcmp(fourmis->role, "OUVRIERE") == 0)
        {
            conso = 2;
        }
        else if (strcmp(fourmis->role, "EXPLORATRICE") == 0)
        {
            conso = 3;
        }

        if (ressources->stockNourriture >= conso)
        {
            ressources->stockNourriture -= conso;
            ressources->Consommation += conso;
            printf("La fourmi %s (Role : %s) a consomme %d unites de nourriture.\n", fourmis[i].nom, fourmis[i].role, conso);
        }

        else
        {
            printf("Pas assez de nourriture pour la fourmi %s (Role : %s).\n", fourmis[i].nom, fourmis[i].role);
        }
    }
}

Fourmiliere creerColonie(int nombreSalles, int nombreReines) // Creer 1 Colonies
{
    Fourmiliere colonie;

    colonie.ressources.stockNourriture = 100 * nombreReines;
    colonie.ressources.stockMateriel = 50;
    colonie.ressources.Consommation = 0;

    colonie.taille = nombreSalles + 1;
    colonie.fourmis = (FourmiChimere *)malloc(sizeof(FourmiChimere) *  TAILLE_INITIAL);
    colonie.decouvertes = 0;

    return colonie;
}

GestionColonies creerGestionColonies(int nombreColonies, int nombreSalles, int nombreReines) // Creer Plusieurs
{
    GestionColonies gestion;

    gestion.nombreColonies = nombreColonies;
    gestion.colonies = (Fourmiliere *)malloc(sizeof(Fourmiliere) * nombreColonies);

    for (int i = 0; i < nombreColonies; i++)
    {
        gestion.colonies[i] = creerColonie(nombreSalles, nombreReines);
    }
    return gestion;
}

void afficherGestionColonies(GestionColonies *gestion)
{
    printf("gestion %d colonies :\n", gestion->nombreColonies);

    for (int i = 0; i < gestion->nombreColonies; i++)
    {
        printf("Colonie %d :\n", i + 1);
        printf("- nourriture : %d\n", gestion->colonies[i].ressources.stockNourriture);
        printf("- materiel : %d\n", gestion->colonies[i].ressources.stockMateriel);
        printf("- nombre de salles : %d\n", gestion->colonies[i].taille);
    }
}

void creerChamp(ChampAgricole *champ, int id, int production, int capacite)
{
    champ->id = id;
    champ->productionParJour = production;
    champ->capaciteMax = capacite;
    champ->nourritureStockee = 0;
}

void produireNourriture(ChampAgricole *champ)
{
    if (champ->nourritureStockee + champ->productionParJour <= champ->capaciteMax)
    {
        champ->nourritureStockee += champ->capaciteMax;
    }
    else
    {
        champ->nourritureStockee = champ->capaciteMax;
    }

    printf("Champ %d a produit %d unites de nourriture. stock actuel : %d\n", champ->id, champ->productionParJour, champ->nourritureStockee);
}

void recolterNourriture(ChampAgricole *champ, Ressources *ressources)
{
    ressources->stockNourriture += champ->nourritureStockee;
    printf("Recolte %d unite de nourriture du champ %d. Stock total : %d\n", champ->nourritureStockee, champ->id, ressources->stockNourriture);
    champ->nourritureStockee = 0;
}

void demarrerProjet(ProjetConstruction *projet, const char *type, int materielNecessaire)
{
    strcpy(projet->type, type);
    projet->materielNecessaire = materielNecessaire;
    projet->progression = 0;
    printf("Pojet de type %s démaré. Materiaux necessaire : %d. \n", projet->type, projet->materielNecessaire);
}

bool avancerProjet(ProjetConstruction *projet, Ressources *ressources)
{
    if (projet->progression >= projet->materielNecessaire)
    {
        printf("Le projet %s est deja termine\n", projet->type);
        return false;
    }

    if (ressources->stockMateriel > 0)
    {
        int materielUtilise = ressources->stockMateriel >= 10 ? 10 : ressources->stockMateriel;
        projet->progression += materielUtilise;
        ressources->stockMateriel -= materielUtilise;

        printf("Projet %s avance de %d unite. Progression : %d/%d.\n", projet->type, materielUtilise, projet->progression, projet->materielNecessaire);

        if (projet->progression >= projet->materielNecessaire)
        {
            printf("Le projet '%s' est maintenant terminé !\n", projet->type);
        }
        return true;
    }

    else
    {
        printf("Pas assez de matériaux disponibles pour avancer le projet '%s'.\n", projet->type);
        return false;
    }
}

void afficherProjet(ProjetConstruction *projet)
{
    printf("Projet '%s' - Progression : %d/%d.\n",
           projet->type, projet->progression, projet->materielNecessaire);
}
