#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "definition_fourmis.h"

void afficher_menu()
{
    printf("************************************************************************************\n");
    printf("******************************** PROJET KIMERA ANTS ********************************\n");
    printf("************************************************************************************\n");
    printf("\nBIENVENUE DANS LE MONDE DU CELEBRE ANIME HUNTERXHUNTER !!!!\n");
    printf("Ce jeu vous propose de simuler une fourmiliere de fourmis chimere du monde d'HxH.\n");
    printf("Vous devez choisir une action dans le menu ci-dessus pour commencer a jouer.\n");
    printf("========================\n");
    printf("\n***** MENU PRINCIPAL *****\n");
    printf("[1] LANCER LA SIMULATION DE LA FOURMILIERE\n");
    printf("[2] DISTRIBUTION DES ROLES\n");
    printf("[3] SIMULATION DU CYCLE DE REPRODUCTION\n");
    printf("[4] DISTRIBUTION DE LA NOURRITURE (tout le monde à la cantine !!!)\n");
    printf("[5] SIMULATION DE LA CHASSE !\n");
    printf("[6] Quitter\n");
    printf("========================\n");
    printf("Votre choix : ");
}

int main()
{
    srand(time(NULL)); // Initialiser la génération de nombres aléatoires

    Fourmiliere *fourmiliere = malloc(sizeof (Fourmiliere));
    init_fourmiliere(fourmiliere, TAILLE_INITIAL);
    Ressources *ressource = NULL;

    int choix;
    int cycle;

    do
    {
        afficher_menu();
        scanf("%d", &choix);
        switch (choix)
        {
        case 1:
            printf("\n***** LANCER LA SIMULATION *****\n");
            break;
        case 2:
            printf("Combien de cycles voulez-vous simuler ? : ");
            scanf("%d", &cycle);
            break;
        case 3:
            simulation_collect_nourriture(fourmiliere, ressource);
            break;
        case 4:
            printf("Au revoir !\n");
            break;
        default:
            printf("Choix invalide. Veuillez réessayer.\n");
        }
    } while (choix != 6);

    // Libérer la mémoire allouée pour la fourmilière
    free(fourmiliere->fourmis);
    free(fourmiliere);

    return 0;
}
